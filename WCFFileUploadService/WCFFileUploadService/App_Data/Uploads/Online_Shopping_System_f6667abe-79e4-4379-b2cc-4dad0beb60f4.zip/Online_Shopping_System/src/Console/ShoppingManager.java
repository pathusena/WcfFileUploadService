package Console;

import java.util.ArrayList;

public interface ShoppingManager {
    ArrayList<Electronics> GetElectronicsList();
    ArrayList<Clothing> GetClothingList();
}
